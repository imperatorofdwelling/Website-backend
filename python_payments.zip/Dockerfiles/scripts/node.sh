#!/usr/bin/env sh

lt --subdomain soulworker-djangos-12345 --port 8000 --local-host payments