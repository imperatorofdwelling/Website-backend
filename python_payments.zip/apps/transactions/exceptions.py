class DuplicateError(Exception):
    pass
